package com.example.softassign2api.Models.Notification;

public enum NotificationChannel {
    EMAIL,
    SMS,
    BOTH
}
