package com.example.softassign2api.Models.Order;

public enum OrderStatus {
    placed,
    shipped,
    cancelled,
    pending
}
