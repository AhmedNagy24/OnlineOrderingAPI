package com.example.softassign2api.Services.Order;

import com.example.softassign2api.Models.Order.Order;

public interface IOrderAction {
    String performAction(Order order);
}
