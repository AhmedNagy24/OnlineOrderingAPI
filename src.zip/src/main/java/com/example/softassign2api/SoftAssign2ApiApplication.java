package com.example.softassign2api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoftAssign2ApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(SoftAssign2ApiApplication.class, args);
    }

}
