package com.example.softassign2api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoftAssign2ApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
